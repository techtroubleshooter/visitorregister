<?php
if(isset($_POST["submit"])){
// Checking For Blank Fields..
if($_POST["vname"]==""||$_POST["vemail"]==""){
echo "Please fill all fields..";
}else{
// Check if the "Sender's Email" input field is filled out
$email=$_POST['vemail'];
// Sanitize E-mail Address
$email =filter_var($email, FILTER_SANITIZE_EMAIL);
// Validate E-mail Address
$email= filter_var($email, FILTER_VALIDATE_EMAIL);
$message= "Visitor Registration";
$subject= "Visitor Registration";
$attachment= "images/xkcd.png";
if (!$email){
echo "Invalid Sender's Email";
}
else{
$headers = 'From:'. $email . "rn"; // Sender's Email
$headers .= 'Cc:'. $email . "rn"; // Carbon copy to Sender


// mail("tech@readingright.in", $subject, $message, $headers);
wp_mail("tech@readingright.in",$subject,$message,$headers,$attachment);
echo "Visitor has been successfully subscribed!";
}
}
}
?>