<!DOCTYPE html>
<html>
<head>
<title>Visitor Registration with Reading Right</title>
<link href="css/elements.css" rel="stylesheet">
</head>

<body>
<div class="container">

<div id="feedback">

<div class="head">
<h3>Visitor Registration with Reading Right</h3>
<p>Please Register yourself with Reading Right and enjoy treasure house of happiness</p>
</div>

<form action="#" id="form" method="post" name="form">
<input name="vname" placeholder="Visitor Name" type="text" value="">
<input name="vemail" placeholder="Visitor Email" type="text" value="">
<input id="send" name="submit" type="submit" value="Subscribe">
<input id="sendunsubscribe" name="submit" type="submit" value="UnSubscribe">
</form>
<h3><?php include "secure_email_code.php"?></h3>
</div>

</div>
</body>

</html>